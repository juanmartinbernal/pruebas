package com.comicsopentrends.model

class Cursors {
    var after: String? = null
    var before: String? = null

    override fun toString(): String {
        return "Cursors{" +
                "after = '" + after + '\''.toString() +
                "}"
    }
}
