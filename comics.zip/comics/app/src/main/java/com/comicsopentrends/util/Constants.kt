package com.comicsopentrends.util

/**
 * Created by Juan Martín Bernal on 21/10/2017.
 */

object Constants {
    //search
    val NUM_MIN_EXECUTE_SEARCH = 3
    val LIMIT = 20
    val WAR_FREQUENCY = "always"

}
