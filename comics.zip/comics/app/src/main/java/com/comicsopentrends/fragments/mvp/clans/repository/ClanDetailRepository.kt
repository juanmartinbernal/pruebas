package com.comicsopentrends.fragments.mvp.clans.repository

interface ClanDetailRepository {
    fun getDetailClan(clanTag: String?)
}
