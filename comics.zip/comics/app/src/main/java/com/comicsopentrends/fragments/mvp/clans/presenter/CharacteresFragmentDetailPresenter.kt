package com.comicsopentrends.fragments.mvp.clans.presenter

/**
 * Created by Asus on 20/10/2017.
 */

interface CharacteresFragmentDetailPresenter {

    fun goToDetail(characterId: String?)
}
