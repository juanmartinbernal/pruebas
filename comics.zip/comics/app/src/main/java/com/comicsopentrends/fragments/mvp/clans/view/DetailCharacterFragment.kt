package com.comicsopentrends.fragments.mvp.clans.view

interface DetailCharacterFragment
